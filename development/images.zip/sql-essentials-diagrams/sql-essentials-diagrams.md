#	SQL Essentials Images

##	About the Database


###	Artworks Schema

![Artworks Schema](images/2-1-prints.png)

###	Properties

![Properties](images/2-3-properties.png)

###	Shopping Cart

![Shopping Cart](images/2-4-shopping-cart.png)

##	Joins


###	Paintings & Artists

![Paintings & Artists](images/6-1-paintings-artists.png)

```sql
SELECT * FROM minipaintings;
SELECT * FROM miniartists;
```

###	Paintings FULL (OUTER) JOIN Artists

![Paintings FULL JOIN Artists](images/6-2-paintings-full-join-artists.png)

```sql
SELECT *
FROM minipaintings FULL /* OUTER */ JOIN miniartists
	ON minipaintings.artistid=miniartists.id;

--	Using Aliases

	SELECT *
	FROM minipaintings AS p FULL /* OUTER */ JOIN miniartists AS a
		ON p.artistid=a.id;
```

###	Paintings LEFT (OUTER) JOIN Artists

![Paintings JOIN Artists](images/6-2-paintings-left-join-artists.png)

```sql
SELECT *
FROM minipaintings AS p FULL /* OUTER */ JOIN miniartists AS a
	ON p.artistid=a.id
WHERE p.id IS NOT NULL;

--	Better:

	SELECT *
	FROM minipaintings AS p LEFT /* OUTER */ JOIN miniartists AS a
		ON p.artistid=a.id;
```

###	Paintings RIGHT (OUTER) JOIN Artists

![Paintings JOIN Artists](images/6-2-paintings-right-join-artists.png)

```sql
SELECT *
FROM minipaintings AS p FULL /* OUTER */ JOIN miniartists AS a
	ON p.artistid=a.id
WHERE a.id IS NOT NULL;

--	Better:

SELECT *
FROM minipaintings AS p RIGHT /* OUTER */ JOIN miniartists AS a
	ON p.artistid=a.id;
```

###	Paintings (INNER) JOIN Artists

![Paintings JOIN Artists](images/6-2-paintings-inner-join-artists.png)

```sql
SELECT *
FROM minipaintings AS p FULL /* OUTER */ JOIN miniartists AS a
	ON p.artistid=a.id
WHERE p.id IS NOT NULL AND a.id IS NOT NULL;

--	Better:

FROM minipaintings AS p /* INNER */ JOIN miniartists AS a
	ON p.artistid=a.id;
```
###	Employees

![Employees](images/6-3-employees.png)

###	Employees Joined

![Employees Joined](images/6-4-employees-joined.png)

```sql
SELECT *
FROM employees AS e LEFT /* OUTER */ JOIN employees AS s
	ON e.supervisorid=s.id;
```

##	Set Operations

###	Union

![Union](images/9-1-union.png)

###	Intersect

![Intersect](images/9-2-intersect.png)

###	Except

![Except](images/9-3-except.png)

##	Clause Order

###	SELECT … FROM

![SELECT … FROM](images/clause-order-1.png)

###	SELECT … FROM … WHERE

![SELECT … FROM … WHERE](images/clause-order-2.png)

###	SELECT … FROM … WHERE … ORDER BY

![SELECT … FROM … WHERE… ORDER BY](images/clause-order-3.png)

###	SELECT … FROM … WHERE … GROUP BY … HAVING … ORDER BY

![SELECT … FROM … WHERE… GROUP BY … HAVING … ORDER BY](images/clause-order-4.png)
